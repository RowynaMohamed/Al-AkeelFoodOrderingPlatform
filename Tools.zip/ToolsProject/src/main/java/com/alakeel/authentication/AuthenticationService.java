package com.alakeel.authentication;

import com.alakeel.customer.*;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.*;

@Stateless
@Path("/auth")
@RolesAllowed({"admin","user","runner"})
public class AuthenticationService {
    @PersistenceContext(unitName = "auth")
    private EntityManager em;

    private ArrayList<Customer> Customers;

    public AuthenticationService() {
        Customers = new ArrayList<>();
    }

    @POST
    @Path("/signin")
    @RolesAllowed({"admin","user","runner"})
    public Response SignIn(@FormParam("username") String Username, @FormParam("password") String Password) {
        Customer customer = null;
        for (Customer c : Customers) {
            if (c.getUsername().equals(Username)) {
                customer = c;
                break;
            }
        }
        if (customer == null) {
            SignUp(Username, Password);
        }
        return Response.ok().build();
    }

    @POST
    @Path("/signup")
    @RolesAllowed({"admin","user","runner"})
    public Response SignUp(@FormParam("username") String Username, @FormParam("password") String Password) {
        Customer customer = null;
        for (Customer c : Customers) {
            if (c.getUsername().equals(Username)) {
                customer = c;
                break;
            }
        }
        if (customer != null) {
            SignIn(Username,Password);
        }
        return Response.ok().build();
    }
}
