package com.alakeel;

public enum Role {
    CUSTOMER,
    RESTAURANT_OWNER,
    RUNNER;
}