package com.alakeel;

import javax.persistence.*;
import javax.ws.rs.*;

@Entity
@Table(name = "users")
@Path("users")
public abstract class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "role")
	private Role role;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@GET
	public String getUser() {
	    return "User: " + this.name + ", ID: " + this.id + ", Role: " + this.role.toString();
	}

	@POST
	public void createUser(String id, String name, Role role) {
	    this.id = id;
	    this.name = name;
	    this.role = role;
	}

	@PUT
	public void updateUser(String name, Role role) {
	    this.name = name;
	    this.role = role;
	}

	@DELETE
	public void deleteUser() {
	    this.id = null;
	    this.name = null;
	    this.role = null;
	}
	public abstract void SignIn (String username, String Password, Role role);
}
