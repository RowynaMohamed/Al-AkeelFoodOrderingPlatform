package com.alakeel;

public enum RunnerStatus {
    AVAILABLE,
    BUSY;
}