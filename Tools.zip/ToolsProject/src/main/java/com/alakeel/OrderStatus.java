package com.alakeel;

public enum OrderStatus {
    PREPARING,
    DELIVERED,
    CANCELED,
    COMPLETED;
}