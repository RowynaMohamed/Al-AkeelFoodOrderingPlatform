package com.alakeel;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.persistence.*;
import javax.ws.rs.*;
import java.util.*;
@Entity
@Table(name = "customers")
@RolesAllowed("customer")
@Path("customers")
public class Customer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private List<Order> orders = new ArrayList<>();
    
    // setters and getters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
    @Inject 
    private EntityManager entityManager;
    // create order by customer
    @POST
    @Path("/{customerId}/order")
    public Order createOrder(@PathParam("customerId") Long customerId, Order order) {
        // get customer from db
        Customer customer = entityManager.find(Customer.class, customerId);
        
        // set customer for order
        order.setCustomer(customer);
        
        // get random runner from db
        Runner runner = getRandomRunner();
        
        // set runner for order and change status to busy
        order.setRunner(runner);
        runner.setStatus(RunnerStatus.BUSY);
        
        // add order to customer's orders list
        customer.getOrders().add(order);
        
        // calculate total receipt value
        Double totalReceiptValue = calculateTotalReceiptValue(order.getItems(), order.getDeliveryFees());
        order.setTotalReceiptValue(totalReceiptValue);
        
        // save changes to db
        entityManager.persist(customer);
        entityManager.flush();
        
        return order;
    }
    
    // edit order
    @PUT
    @Path("/{customerId}/order/{orderId}")
    public Order editOrder(@PathParam("customerId") Long customerId, @PathParam("orderId") Long orderId, Order updatedOrder) {
        // get order from db
        Order order = entityManager.find(Order.class, orderId);
        
        // check if order is not canceled and in preparing state to be edited
        if (order.getOrderStatus() == OrderStatus.CANCELED || order.getOrderStatus() == OrderStatus.DELIVERED) {
            throw new RuntimeException("Cannot edit a canceled or delivered order.");
        }
        if (order.getOrderStatus() != OrderStatus.PREPARING) {
            throw new RuntimeException("Order must be in preparing state to be edited.");
        }
        
        // update order items
        order.setItems(updatedOrder.getItems());
        
        // calculate total receipt value
        Double totalReceiptValue = calculateTotalReceiptValue(order.getItems(), order.getDeliveryFees());
        order.setTotalReceiptValue(totalReceiptValue);
        
        // save changes to db
        entityManager.persist(order);
        entityManager.flush();
        
        return order;
    }
    
    // list all restaurants
    @GET
    @Path("/restaurants")
    public List<Restaurant> listAllRestaurants() {
        // get all restaurants from db
        TypedQuery<Restaurant> query = entityManager.createQuery("SELECT r FROM Restaurant r", Restaurant.class);
        List<Restaurant> restaurants = query.getResultList();
        
        return restaurants;
    }
    
    // helper method to get random runner from db
    private Runner getRandomRunner() {
        // get all available runners from db
        TypedQuery<Runner> query = entityManager.createQuery("SELECT r FROM Runner r WHERE r.status = :status", Runner.class);
        query.setParameter("status", RunnerStatus.AVAILABLE);
        List<Runner> runners = query.getResultList();
        
        // select random runner from list
        Random rand = new Random();
        int index = rand.nextInt(runners.size());
        Runner runner = runners.get(index);
        
        return runner;
    }
    
    // helper method to calculate total receipt value
    private Double calculateTotalReceiptValue(List<Meal> items, Double deliveryFees) {
        Double total = 0.0;
        
        for (Meal item : items) {
            total += item.getPrice();
        }
        
        total += deliveryFees;
        
        return total;
    }
    public void SignIn (String username, String Password, Role role) {
		User u = new RestaurantOwner();
		u.setUsername(username);
		u.setPassword(Password);
		u.setRole(Role.CUSTOMER);
	}
}
