package com.alakeel;
import javax.persistence.*;
import java.util.*;
@Entity
public class Order {
    @Id
    private String id;
    @ManyToMany
    @JoinTable(
        name = "order_meal",
        joinColumns = @JoinColumn(name = "order_id"),
        inverseJoinColumns = @JoinColumn(name = "meal_id"))
    private List<Meal> items;
    private double totalPrice;
    @ManyToOne
    @JoinColumn(name = "runner_id")
    private Runner runner;
    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;
    private OrderStatus orderStatus;
    private Double totalReceiptValue;
    private Double DeliveryFees;
    private Customer customer;

    public void setDeliveryFees(Double deliveryFees) {
		DeliveryFees = deliveryFees;
	}
	public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public List<Meal> getItems() {
        return items;
    }
    public void setItems(List<Meal> items) {
        this.items = items;
    }
    public double getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    public Runner getRunner() {
        return runner;
    }
    public void setRunner(Runner runner) {
        this.runner = runner;
    }
    public Restaurant getRestaurant() {
        return restaurant;
    }
    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
    public OrderStatus getOrderStatus() {
        return orderStatus;
    }
    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }
	public Double getTotalReceiptValue() {
		return totalReceiptValue;
	}
	public void setTotalReceiptValue(Double totalReceiptValue) {
		this.totalReceiptValue = totalReceiptValue;
	}
	public Double getDeliveryFees() {
		return DeliveryFees;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
}