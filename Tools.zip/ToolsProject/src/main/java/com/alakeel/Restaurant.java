package com.alakeel;

import java.util.*;

import javax.annotation.security.RolesAllowed;
import javax.ejb.*;
import javax.persistence.*;
import javax.ws.rs.*;

@Stateless
@Path("/restaurants")
@RolesAllowed("owner")
public class Restaurant {
	@Id
	private String id;
	private String name;
	@OneToMany(mappedBy = "restaurant")
	private List<Meal> menu;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Meal> getMenu() {
		return menu;
	}

	public void setMenu(List<Meal> menu) {
		this.menu = menu;
	}

	@PersistenceContext(unitName = "restaurant")
	private EntityManager entityManager;

	@POST
	public void create(Restaurant restaurant) {
		entityManager.persist(restaurant);
	}

	@PUT
	@Path("/{id}")
	public void update(@PathParam("id") String id, Restaurant restaurant) {
		Restaurant existingRestaurant = entityManager.find(Restaurant.class, id);
		if (existingRestaurant != null) {
			existingRestaurant.setName(restaurant.getName());
			existingRestaurant.setMenu(restaurant.getMenu());
			entityManager.merge(existingRestaurant);
		}
	}

	@DELETE
	@Path("/{id}")
	public void delete(@PathParam("id") String id) {
		Restaurant restaurant = entityManager.find(Restaurant.class, id);
		if (restaurant != null) {
			entityManager.remove(restaurant);
		}
	}

	@GET
	@Path("/{id}")
	public Restaurant getById(@PathParam("id") String id) {
		return entityManager.find(Restaurant.class, id);
	}

	@GET
	public List<Restaurant> getAll() {
		Query query = entityManager.createQuery("SELECT r FROM Restaurant r");
		return query.getResultList();
	}
}