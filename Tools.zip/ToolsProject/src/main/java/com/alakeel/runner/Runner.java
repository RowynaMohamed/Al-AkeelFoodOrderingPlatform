package com.alakeel.runner;

import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "runner")
@Path("/runner")
public class Runner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long RunnerID;

    private String name;

    @Enumerated(EnumType.STRING)
    private RunnerAvailability availability;

    @OneToOne(cascade = CascadeType.ALL)
    private RunnerService service;

    // Constructors, getters, and setters

    public Runner() {}

    public Runner(String name, RunnerAvailability availability, RunnerService service) {
        this.name = name;
        this.availability = availability;
        this.service = service;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRunner(@PathParam("id") long id) {
        Runner runner = getRunnerById(id);
        if (runner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(runner).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createRunner(Runner runner) {
        createNewRunner(runner);
        return Response.status(Response.Status.CREATED).entity(runner).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRunner(@PathParam("id") long id, Runner runner) {
        Runner existingRunner = getRunnerById(id);
        if (existingRunner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingRunner.setName(runner.getName());
            existingRunner.setAvailability(runner.getAvailability());
            existingRunner.setService(runner.getService());
            updateRunner(existingRunner);
            return Response.ok(existingRunner).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteRunner(@PathParam("id") long id) {
        Runner existingRunner = getRunnerById(id);
        if (existingRunner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteRunner(existingRunner);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private Runner getRunnerById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Runner runner = em.find(Runner.class, id);
        em.close();
        return runner;
    }

    private void createNewRunner(Runner runner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(runner);
        em.getTransaction().commit();
        em.close();
    }

    private void updateRunner(Runner runner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(runner);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteRunner(Runner runner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(runner) ? runner : em.merge(runner));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return RunnerID;
    }

    public void setId(Long id) {
       this.RunnerID = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RunnerAvailability getAvailability() {
        return availability;
    }

    public void setAvailability(RunnerAvailability availability) {
        this.availability = availability;
    }

    public RunnerService getService() {
        return service;
    }

    public void setService(RunnerService service) {
        this.service = service;
    }
}
