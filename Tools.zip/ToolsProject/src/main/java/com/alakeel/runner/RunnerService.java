package com.alakeel.runner;

import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "runner_service")
@Path("/service")
public class RunnerService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ServiceId;

    private String name;

    private double price;

    // Constructors, getters, and setters

    public RunnerService() {}

    public RunnerService(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getService(@PathParam("id") long id) {
        RunnerService service = getServiceById(id);
        if (service == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(service).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createService(RunnerService service) {
        createNewService(service);
        return Response.status(Response.Status.CREATED).entity(service).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateService(@PathParam("id") long id, RunnerService service) {
        RunnerService existingService = getServiceById(id);
        if (existingService == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingService.setName(service.getName());
            existingService.setPrice(service.getPrice());
            updateService(existingService);
            return Response.ok(existingService).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteService(@PathParam("id") long id) {
        RunnerService existingService = getServiceById(id);
        if (existingService == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteService(existingService);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private RunnerService getServiceById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        RunnerService service = em.find(RunnerService.class, id);
        em.close();
        return service;
    }

    private void createNewService(RunnerService service) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(service);
        em.getTransaction().commit();
        em.close();
    }

    private void updateService(RunnerService service) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(service);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteService(RunnerService service) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(service) ? service : em.merge(service));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return ServiceId;
    }

    public void setId(Long id) {
        this.ServiceId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
