package com.alakeel.runner;

public enum RunnerAvailability {
	AVAILABLE,
    BUSY,
}
