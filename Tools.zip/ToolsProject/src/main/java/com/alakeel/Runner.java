package com.alakeel;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.persistence.*;
import javax.ws.rs.*;
import java.util.*;

@Entity
@Table(name = "runner")
@RolesAllowed("runner")
@Path("runner")
public class Runner extends User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "status")
    private RunnerStatus status;
    
    @Column(name = "delivery_fees")
    private double deliveryFees;
    
    @OneToMany(mappedBy = "runner", cascade = CascadeType.ALL)
    private List<Order> orders;
    
    // constructor
    public Runner(String id, String name, RunnerStatus status, double deliveryFees, List<Order> orders) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.deliveryFees = deliveryFees;
        this.orders = orders;
    }

    // Getter and setter methods for the fields
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public RunnerStatus getStatus() {
        return status;
    }
    public void setStatus(RunnerStatus status) {
        this.status = status;
    }
    public double getDeliveryFees() {
        return deliveryFees;
    }
    public void setDeliveryFees(double deliveryFees) {
        this.deliveryFees = deliveryFees;
    }
    public List<Order> getOrders() {
        return orders;
    }
    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }


    // JPA annotation for HTTP GET request
    @GET
    public Runner getRunner() {
        // logic to retrieve runner from database
        return this;
    }

    // JPA annotation for HTTP POST request
    @POST
    public void markOrderDelivered() {
        // logic to mark order as delivered
        // logic to update runner status to available
        setStatus(RunnerStatus.AVAILABLE);
        // save changes to database
    }

    // JPA annotation for HTTP PUT request
    @PUT
    public void updateRunner(Runner updatedRunner) {
        // logic to update runner record with new information
        setName(updatedRunner.getName());
        setStatus(updatedRunner.getStatus());
        setDeliveryFees(updatedRunner.getDeliveryFees());
        // save changes to database
    }

    // JPA annotation for HTTP DELETE request
    @DELETE
    public void deleteRunner() {
        // get an instance of EntityManager
        EntityManager entityManager = Persistence.createEntityManagerFactory("persistence-unit-name").createEntityManager();
        
        // begin transaction
        entityManager.getTransaction().begin();

        // find the Runner entity by ID
        Runner runner = entityManager.find(Runner.class, getId());

        // if the Runner entity exists, remove it
        if (runner != null) {
            entityManager.remove(runner);
        }

        // commit the transaction
        entityManager.getTransaction().commit();
    }


    // method to get the number of trips completed by the runner
    public int getTripsCompleted() {
        int tripsCompleted = 0;
        // logic to iterate over all orders assigned to the runner
        for (Order order : orders) {
            if (order.getOrderStatus() == OrderStatus.COMPLETED && order.getOrderStatus() != OrderStatus.CANCELED) {
                tripsCompleted++;
            }
        }
        return tripsCompleted;
    }
    public void SignIn (String username, String Password, Role role) {
		User u = new RestaurantOwner();
		u.setUsername(username);
		u.setPassword(Password);
		u.setRole(Role.RUNNER);
	}
}
