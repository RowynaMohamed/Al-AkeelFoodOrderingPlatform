package com.alakeel.restaurant;

import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "meals")
@Path("/meal")
public class Meal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long meal_id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private double price;

    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;

    // Constructors, getters and setters

    public Meal() {}

    public Meal(String name, String description, double price, Restaurant restaurant) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.restaurant = restaurant;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMeal(@PathParam("id") long id) {
        Meal meal = getMealById(id);
        if (meal == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(meal).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMeal(Meal meal) {
        createNewMeal(meal);
        return Response.status(Response.Status.CREATED).entity(meal).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMeal(@PathParam("id") long id, Meal meal) {
        Meal existingMeal = getMealById(id);
        if (existingMeal == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingMeal.setName(meal.getName());
            existingMeal.setDescription(meal.getDescription());
            existingMeal.setPrice(meal.getPrice());
            existingMeal.setRestaurant(meal.getRestaurant());
            updateMeal(existingMeal);
            return Response.ok(existingMeal).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteMeal(@PathParam("id") long id) {
        Meal existingMeal = getMealById(id);
        if (existingMeal == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteMeal(existingMeal);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private Meal getMealById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Meal meal = em.find(Meal.class, id);
        em.close();
        return meal;
    }

    private void createNewMeal(Meal meal) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(meal);
        em.getTransaction().commit();
        em.close();
    }

    private void updateMeal(Meal meal) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(meal);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteMeal(Meal meal) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(meal) ? meal : em.merge(meal));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getMeal_id() {
        return meal_id;
    }

    public void setMeal_id(Long id) {
        this.meal_id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
}
