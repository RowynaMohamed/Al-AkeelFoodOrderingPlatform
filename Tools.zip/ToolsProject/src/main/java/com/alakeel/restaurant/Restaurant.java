package com.alakeel.restaurant;

import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "restaurants")
@Path("/restaurant")
public class Restaurant implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long restaurant_id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String address;

    @OneToMany(mappedBy = "restaurant", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Meal> meals = new ArrayList<>();

    // Constructors, getters and setters

    public Restaurant() {}

    public Restaurant(String name, String address) {
        this.name = name;
        this.address = address;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRestaurant(@PathParam("id") long id) {
        Restaurant restaurant = getRestaurantById(id);
        if (restaurant == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(restaurant).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createRestaurant(Restaurant restaurant) {
        createNewRestaurant(restaurant);
        return Response.status(Response.Status.CREATED).entity(restaurant).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRestaurant(@PathParam("id") long id, Restaurant restaurant) {
        Restaurant existingRestaurant = getRestaurantById(id);
        if (existingRestaurant == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingRestaurant.setName(restaurant.getName());
            existingRestaurant.setAddress(restaurant.getAddress());
            updateRestaurant(existingRestaurant);
            return Response.ok(existingRestaurant).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteRestaurant(@PathParam("id") long id) {
        Restaurant existingRestaurant = getRestaurantById(id);
        if (existingRestaurant == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteRestaurant(existingRestaurant);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private Restaurant getRestaurantById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Restaurant restaurant = em.find(Restaurant.class, id);
        em.close();
        return restaurant;
    }

    private void createNewRestaurant(Restaurant restaurant) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(restaurant);
        em.getTransaction().commit();
        em.close();
    }

    private void updateRestaurant(Restaurant restaurant) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(restaurant);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteRestaurant(Restaurant restaurant) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(restaurant) ? restaurant : em.merge(restaurant));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(Long id) {
        this.restaurant_id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Meal> getMeals() {
        return meals;
    }

    public void setMeals(List<Meal> meals) {
        this.meals = meals;
    }

    public void addMeal(Meal meal) {
        meals.add(meal);
        meal.setRestaurant(this);

    }

    public void removeMeal(Meal meal) {
        meals.remove(meal);
        meal.setRestaurant(null);
    }
}
