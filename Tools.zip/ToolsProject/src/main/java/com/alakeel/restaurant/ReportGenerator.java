package com.alakeel.restaurant;

public interface ReportGenerator {
	Report generateReport();
}
