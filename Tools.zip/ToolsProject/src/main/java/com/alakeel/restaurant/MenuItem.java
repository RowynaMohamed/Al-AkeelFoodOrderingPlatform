package com.alakeel.restaurant;

import javax.annotation.security.RolesAllowed;
import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "menu_item")
@Path("/menu-item")
@RolesAllowed({"admin","user"})
public class MenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private double price;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "menu_id")
    private Menu menu;

    // Constructors, getters, and setters

    public MenuItem() {}

    public MenuItem(String name, double price, Menu menu) {
        this.name = name;
        this.price = price;
        this.menu = menu;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("user")
    public Response getMenuItem(@PathParam("id") long id) {
        MenuItem menuItem = getMenuItemById(id);
        if (menuItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(menuItem).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Response createMenuItem(MenuItem menuItem) {
        createNewMenuItem(menuItem);
        return Response.status(Response.Status.CREATED).entity(menuItem).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMenuItem(@PathParam("id") long id, MenuItem menuItem) {
        MenuItem existingMenuItem = getMenuItemById(id);
        if (existingMenuItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingMenuItem.setName(menuItem.getName());
            existingMenuItem.setPrice(menuItem.getPrice());
            existingMenuItem.setMenu(menuItem.getMenu());
            updateMenuItem(existingMenuItem);
            return Response.ok(existingMenuItem).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @RolesAllowed("admin")
    public Response deleteMenuItem(@PathParam("id") long id) {
        MenuItem existingMenuItem = getMenuItemById(id);
        if (existingMenuItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteMenuItem(existingMenuItem);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private MenuItem getMenuItemById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        MenuItem menuItem = em.find(MenuItem.class, id);
        em.close();
        return menuItem;
    }

    private void createNewMenuItem(MenuItem menuItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(menuItem);
        em.getTransaction().commit();
        em.close();
    }

    private void updateMenuItem(MenuItem menuItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(menuItem);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteMenuItem(MenuItem menuItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(menuItem) ? menuItem : em.merge(menuItem));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }
}
