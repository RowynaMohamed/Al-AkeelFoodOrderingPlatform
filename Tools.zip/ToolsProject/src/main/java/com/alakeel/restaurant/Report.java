package com.alakeel.restaurant;

import javax.annotation.security.RolesAllowed;
import javax.persistence.*;
import java.util.Date;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
@Entity
@Table(name = "report")
@Path("/report")
@RolesAllowed("admin")
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Date date;

    private double totalSales;

    // Constructors, getters, and setters

    public Report() {}

    public Report(Date date, double totalSales) {
        this.date = date;
        this.totalSales = totalSales;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getReport(@PathParam("id") long id) {
        Report report = getReportById(id);
        if (report == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(report).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Response createReport(Report report) {
        createNewReport(report);
        return Response.status(Response.Status.CREATED).entity(report).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Response updateReport(@PathParam("id") long id, Report report) {
        Report existingReport = getReportById(id);
        if (existingReport == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingReport.setDate(report.getDate());
            existingReport.setTotalSales(report.getTotalSales());
            updateReport(existingReport);
            return Response.ok(existingReport).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @RolesAllowed("admin")
    public Response deleteReport(@PathParam("id") long id) {
        Report existingReport = getReportById(id);
        if (existingReport == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteReport(existingReport);
            return Response.noContent().build();
        }
    }

    private Report getReportById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Report report = em.find(Report.class, id);
        em.close();
        return report;
    }

    private void createNewReport(Report report) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(report);
        em.getTransaction().commit();
        em.close();
    }

    private void updateReport(Report report) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(report);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteReport(Report report) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(report) ? report : em.merge(report));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }
}