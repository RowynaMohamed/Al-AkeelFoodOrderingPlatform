package com.alakeel.restaurant;

import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "restaurant_owner")
@Path("/owner")
public class RestaurantOwner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String email;

    // Constructors, getters, and setters

    public RestaurantOwner() {}

    public RestaurantOwner(String name, String email) {
        this.name = name;
        this.email = email;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOwner(@PathParam("id") long id) {
        RestaurantOwner owner = getOwnerById(id);
        if (owner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(owner).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createOwner(RestaurantOwner owner) {
        createNewOwner(owner);
        return Response.status(Response.Status.CREATED).entity(owner).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOwner(@PathParam("id") long id, RestaurantOwner owner) {
        RestaurantOwner existingOwner = getOwnerById(id);
        if (existingOwner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingOwner.setName(owner.getName());
            existingOwner.setEmail(owner.getEmail());
            updateOwner(existingOwner);
            return Response.ok(existingOwner).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteOwner(@PathParam("id") long id) {
        RestaurantOwner existingOwner = getOwnerById(id);
        if (existingOwner == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteOwner(existingOwner);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private RestaurantOwner getOwnerById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        RestaurantOwner owner = em.find(RestaurantOwner.class, id);
        em.close();
        return owner;
    }

    private void createNewOwner(RestaurantOwner owner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(owner);
        em.getTransaction().commit();
        em.close();
    }

    private void updateOwner(RestaurantOwner owner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(owner);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteOwner(RestaurantOwner owner) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(owner) ? owner : em.merge(owner));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
