package com.alakeel.restaurant;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path("/service")
public class RestaurantService {

    @PersistenceContext(unitName = "restaurant")
    private EntityManager em;

    @POST
    @Path("/menu")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createMenu(Menu menu) {
        em.persist(menu);
        return Response.status(Response.Status.CREATED).build();
    }

    @GET
    @Path("/menu")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Menu> getAllMenus() {
        return em.createQuery("SELECT m FROM Menu m", Menu.class).getResultList();
    }

    @POST
    @Path("/report")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createReport(Report report) {
        em.persist(report);
        return Response.status(Response.Status.CREATED).build();
    }

    @GET
    @Path("/report")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Report> getAllReports() {
        return em.createQuery("SELECT r FROM Report r", Report.class).getResultList();
    }
}
