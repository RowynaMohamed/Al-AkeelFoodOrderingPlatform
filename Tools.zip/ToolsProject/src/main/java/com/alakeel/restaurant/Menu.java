package com.alakeel.restaurant;
import java.util.*;
import javax.persistence.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "menu")
@Path("/menu")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "menu", cascade = CascadeType.ALL)
    private List<MenuItem> items;

    // Constructors, getters, and setters

    public Menu() {}

    public Menu(List<MenuItem> items) {
        this.items = items;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMenu(@PathParam("id") long id) {
        Menu menu = getMenuById(id);
        if (menu == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(menu).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMenu(Menu menu) {
        createNewMenu(menu);
        return Response.status(Response.Status.CREATED).entity(menu).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMenu(@PathParam("id") long id, Menu menu) {
        Menu existingMenu = getMenuById(id);
        if (existingMenu == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingMenu.setItems(menu.getItems());
            updateMenu(existingMenu);
            return Response.ok(existingMenu).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteMenu(@PathParam("id") long id) {
        Menu existingMenu = getMenuById(id);
        if (existingMenu == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteMenu(existingMenu);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private Menu getMenuById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Menu menu = em.find(Menu.class, id);
        em.close();
        return menu;
    }

    private void createNewMenu(Menu menu) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(menu);
        em.getTransaction().commit();
        em.close();
    }

    private void updateMenu(Menu menu) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(menu);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteMenu(Menu menu) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(menu) ? menu : em.merge(menu));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<MenuItem> getItems() {
        return items;
    }

    public void setItems(List<MenuItem> items) {
        this.items = items;
    }
}
