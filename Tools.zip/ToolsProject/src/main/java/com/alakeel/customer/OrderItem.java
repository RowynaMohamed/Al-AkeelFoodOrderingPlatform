package com.alakeel.customer;

import javax.persistence.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import java.io.Serializable;
import java.util.List;

import com.alakeel.restaurant.Meal;

@Entity
@Table(name = "order_items")
@Path("/orderitem")
public class OrderItem implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne
    @JoinColumn(name = "meal_id")
    private Meal meal;

    @Column(nullable = false)
    private int quantity;

    @Column(nullable = false)
    private double price;

    // Constructors, getters and setters

    public OrderItem() {}

    public OrderItem(Order order, Meal meal, int quantity, double price) {
        this.order = order;
        this.meal = meal;
        this.quantity = quantity;
        this.price = price;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOrderItem(@PathParam("id") Long id) {
        OrderItem orderItem = getOrderItemById(id);
        if (orderItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(orderItem).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createOrderItem(OrderItem orderItem) {
        createNewOrderItem(orderItem);
        return Response.status(Response.Status.CREATED).entity(orderItem).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOrderItem(@PathParam("id") Long id, OrderItem orderItem) {
        OrderItem existingOrderItem = getOrderItemById(id);
        if (existingOrderItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingOrderItem.setMeal(orderItem.getMeal());
            existingOrderItem.setQuantity(orderItem.getQuantity());
            existingOrderItem.setPrice(orderItem.getPrice());
            updateOrderItem(existingOrderItem);
            return Response.ok(existingOrderItem).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteOrderItem(@PathParam("id") Long id) {
        OrderItem existingOrderItem = getOrderItemById(id);
        if (existingOrderItem == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteOrderItem(existingOrderItem);
            return Response.noContent().build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<OrderItem> getAllOrderItems() {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        List<OrderItem> orderItems = em.createQuery("SELECT oi FROM OrderItem oi", OrderItem.class).getResultList();
        em.close();
        return orderItems;
    }

    // JPA methods to interact with the database

    private OrderItem getOrderItemById(Long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        OrderItem orderItem = em.find(OrderItem.class, id);
        em.close();
        return orderItem;
    }

    private void createNewOrderItem(OrderItem orderItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(orderItem);
        em.getTransaction().commit();
        em.close();
    }

    private void updateOrderItem(OrderItem orderItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(orderItem);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteOrderItem(OrderItem orderItem) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(orderItem) ? orderItem : em.merge(orderItem));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Meal getMeal() {
        return meal;
    }

    public void setMeal(Meal meal) {
        this.meal = meal;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
    	return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
}