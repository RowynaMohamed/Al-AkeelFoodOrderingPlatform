package com.alakeel.customer;

public enum OrderStatus {
    COMPLETED,
    CANCELLED
}
