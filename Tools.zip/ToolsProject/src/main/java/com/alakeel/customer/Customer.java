package com.alakeel.customer;

import java.io.Serializable;

import javax.annotation.security.RolesAllowed;
import javax.persistence.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Entity
@Table(name = "customers")
@RolesAllowed("customer")
public class Customer implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String username;

	private String password;

	// constructors
	public Customer() {
	}

	public Customer(String username, String password) {
		this.username = username;
		this.password = password;
	}

	// getters and setters
	@Id
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getId(@PathParam("id") Long id) {
		return Response.ok(this).build();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@PUT
	@Path("/{id}/username")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response setUsername(@PathParam("id") Long id, String username) {
		this.username = username;
		return Response.ok().build();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@PUT
	@Path("/{id}/password")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response setPassword(@PathParam("id") Long id, String password) {
		this.password = password;
		return Response.ok().build();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@RolesAllowed("admin")
	public Response createCustomer(Customer customer) {
		return Response.ok(customer).build();
	}
}