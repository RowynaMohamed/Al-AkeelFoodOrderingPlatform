package com.alakeel.customer;

import javax.annotation.security.RolesAllowed;
import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "review")
@Path("/review")
@RolesAllowed({"user","admin","runner"})
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String comment;

    private int rating;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    // Constructors, getters, and setters

    public Review() {}

    public Review(String comment, int rating, Customer customer) {
        this.comment = comment;
        this.rating = rating;
        this.customer = customer;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("runner")
    public Response getReview(@PathParam("id") long id) {
        Review review = getReviewById(id);
        if (review == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(review).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("user")
    public Response createReview(Review review) {
        createNewReview(review);
        return Response.status(Response.Status.CREATED).entity(review).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("user")
    public Response updateReview(@PathParam("id") long id, Review review) {
        Review existingReview = getReviewById(id);
        if (existingReview == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingReview.setComment(review.getComment());
            existingReview.setRating(review.getRating());
            existingReview.setCustomer(review.getCustomer());
            updateReview(existingReview);
            return Response.ok(existingReview).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @RolesAllowed({"user","admin"})
    public Response deleteReview(@PathParam("id") long id) {
        Review existingReview = getReviewById(id);
        if (existingReview == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deleteReview(existingReview);
            return Response.noContent().build();
        }
    }

    private Review getReviewById(long id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Review review = em.find(Review.class, id);
        em.close();
        return review;
    }

    private void createNewReview(Review review) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(review);
        em.getTransaction().commit();
        em.close();
    }

    private void updateReview(Review review) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(review);
        em.getTransaction().commit();
        em.close();
    }

    private void deleteReview(Review review) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(review) ? review : em.merge(review));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
