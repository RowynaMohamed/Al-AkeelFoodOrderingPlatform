package com.alakeel.customer;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Entity
@Table(name = "customer_service")
@Path("/services")
public class CustomerService {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    
    private String description;
    
    private double price;
    
    // Constructors, getters, and setters
    
    public CustomerService() {}
    
    public CustomerService(String name, String description, double price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getId(@PathParam("id") Long id) {
        return Response.ok(this).build();
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    @GET
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllServices() {
        // retrieve all services from the database
        // and return them as a JSON response
        return Response.ok().build();
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    @PUT
    @Path("/{id}/name")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response setName(@PathParam("id") Long id, String name) {
        this.name = name;
        return Response.ok().build();
    }
    
    @PUT
    @Path("/{id}/description")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response setDescription(@PathParam("id") Long id, String description) {
        this.description = description;
        return Response.ok().build();
    }
    
    @PUT
    @Path("/{id}/price")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response setPrice(@PathParam("id") Long id, double price) {
        this.price = price;
        return Response.ok().build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createService(CustomerService service) {
        // save the new service to the database
        // and return the newly created service object with the generated ID
        return Response.ok(service).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteService(@PathParam("id") Long id) {
        // delete the service with the specified ID from the database
        return Response.ok().build();
    }
}