package com.alakeel.customer;
import javax.annotation.security.RolesAllowed;
import javax.persistence.*;
import java.io.Serializable;
import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.annotation.*;

@Entity
@Table(name = "orders")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@RolesAllowed({"user", "admin"}) // restrict access to authenticated users with 'user' or 'admin' role
public class Order implements Serializable {
	@PersistenceContext(unitName = "Order")
	private EntityManager em;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "order_date")
    private Date orderDate;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems;

    // Constructors, getters, and setters

    public Order() {}

    public Order(int id, Date orderDate, List<OrderItem> orderItems) {
        this.id = id;
        this.orderDate = orderDate;
        this.orderItems = orderItems;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed({"admin", "user"})
    public Response createOrder(Order order) {
        em.persist(order);
        return Response.ok(order).build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Order> getAllOrders() {
        TypedQuery<Order> query = em.createQuery("SELECT o FROM Order o", Order.class);
        return query.getResultList();
    }

    @GET
    @Path("/{orderId}")
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Order getOrderById(@PathParam("orderId") int orderId) {
        Order order = em.find(Order.class, orderId);
        if (order == null) {
            throw new NotFoundException();
        }
        return order;
    }

    @PUT
    @Path("/{orderId}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed({"admin", "user"})
    public Response updateOrder(@PathParam("orderId") int orderId, Order orderUpdates) {
        Order order = em.find(Order.class, orderId);
        if (order == null) {
            throw new NotFoundException();
        }
        order.setOrderDate(orderUpdates.getOrderDate());
        order.setOrderItems(orderUpdates.getOrderItems());
        em.merge(order);
        return Response.ok(order).build();
    }

    @DELETE
    @Path("/{orderId}")
    @RolesAllowed({"admin", "user"})
    public Response deleteOrder(@PathParam("orderId") int orderId) {
        Order order = em.find(Order.class, orderId);
        if (order == null) {
            throw new NotFoundException();
        }
        em.remove(order);
        return Response.noContent().build();
    }
}
