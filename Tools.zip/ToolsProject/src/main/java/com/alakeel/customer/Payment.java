package com.alakeel.customer;

import java.util.Date;
import javax.persistence.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Entity
@Table(name = "payments")
@Path("/payment")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date paymentDate;

    @Column(nullable = false)
    private String paymentMethod;

    // Constructors, getters, and setters

    public Payment() {}

    public Payment(double amount, Date paymentDate, String paymentMethod) {
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPayment(@PathParam("id") int id) {
        Payment payment = getPaymentById(id);
        if (payment == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            return Response.ok(payment).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPayment(Payment payment) {
        createNewPayment(payment);
        return Response.status(Response.Status.CREATED).entity(payment).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatePayment(@PathParam("id") int id, Payment payment) {
        Payment existingPayment = getPaymentById(id);
        if (existingPayment == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            existingPayment.setAmount(payment.getAmount());
            existingPayment.setPaymentDate(payment.getPaymentDate());
            existingPayment.setPaymentMethod(payment.getPaymentMethod());
            updatePayment(existingPayment);
            return Response.ok(existingPayment).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deletePayment(@PathParam("id") int id) {
        Payment existingPayment = getPaymentById(id);
        if (existingPayment == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        } else {
            deletePayment(existingPayment);
            return Response.noContent().build();
        }
    }

    // JPA methods to interact with the database

    private Payment getPaymentById(int id) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        Payment payment = em.find(Payment.class, id);
        em.close();
        return payment;
    }

    private void createNewPayment(Payment payment) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.persist(payment);
        em.getTransaction().commit();
        em.close();
    }

    private void updatePayment(Payment payment) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.merge(payment);
        em.getTransaction().commit();
        em.close();
    }

    private void deletePayment(Payment payment) {
        EntityManager em = Persistence.createEntityManagerFactory("persistence").createEntityManager();
        em.getTransaction().begin();
        em.remove(em.contains(payment) ? payment : em.merge(payment));
        em.getTransaction().commit();
        em.close();
    }

    // getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
