package com.alakeel;

import javax.annotation.security.RolesAllowed;
import javax.persistence.*;
import javax.ws.rs.*;

import java.util.List;

@Entity
@RolesAllowed("owner")
public class RestaurantOwner extends User {
    @Id
    private String id;
    private String name;
    @OneToMany(mappedBy = "owner")
    private List<Restaurant> restaurants;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List<Restaurant> getRestaurants() {
        return restaurants;
    }
    public void setRestaurants(List<Restaurant> restaurants) {
        this.restaurants = restaurants;
    }

    // Create restaurant menu
    @POST
    @Path("/restaurants/{restaurantId}/menu")
    public Meal createMeal(@PathParam("restaurantId") String restaurantId, Meal meal) {
        EntityManager em = Persistence.createEntityManagerFactory("my-persistence-unit").createEntityManager();
        Restaurant restaurant = em.find(Restaurant.class, restaurantId);
        if (restaurant == null) {
            throw new NotFoundException();
        }
        meal.setRestaurant(restaurant);
        em.getTransaction().begin();
        em.persist(meal);
        em.getTransaction().commit();
        em.close();
        return meal;
    }

    // Edit restaurant: change menu meals for each restaurant
    @PUT
    @Path("/restaurants/{restaurantId}/menu")
    public List<Meal> updateMenu(@PathParam("restaurantId") String restaurantId, List<Meal> newMenu) {
        EntityManager em = Persistence.createEntityManagerFactory("my-persistence-unit").createEntityManager();
        Restaurant restaurant = em.find(Restaurant.class, restaurantId);
        if (restaurant == null) {
            throw new NotFoundException();
        }
        List<Meal> oldMenu = restaurant.getMenu();
        // Remove old meals not in the new menu
        for (Meal oldMeal : oldMenu) {
            if (!newMenu.contains(oldMeal)) {
                oldMeal.setRestaurant(null);
                em.getTransaction().begin();
                em.remove(oldMeal);
                em.getTransaction().commit();
            }
        }
        // Add new meals not in the old menu
        for (Meal newMeal : newMenu) {
            if (!oldMenu.contains(newMeal)) {
                newMeal.setRestaurant(restaurant);
                em.getTransaction().begin();
                em.persist(newMeal);
                em.getTransaction().commit();
            }
        }
        restaurant.setMenu(newMenu);
        em.getTransaction().begin();
        em.merge(restaurant);
        em.getTransaction().commit();
        em.close();
        return newMenu;
    }

    // Get restaurant details by id
    @GET
    @Path("/restaurants/{restaurantId}")
    public Restaurant getRestaurant(@PathParam("restaurantId") String restaurantId) {
        EntityManager em = Persistence.createEntityManagerFactory("my-persistence-unit").createEntityManager();
        Restaurant restaurant = em.find(Restaurant.class, restaurantId);
        if (restaurant == null) {
            throw new NotFoundException();
        }
        em.close();
        return restaurant;
    }

    // Create restaurant report: given a restaurant id print how much the restaurant
    // earns (summation of total amount of all completed orders), Number of completed orders, Number of canceled orders
    @GET
    @Path("/restaurants/{restaurantId}/report")
    public String generateReport(@PathParam("restaurantId") String restaurantId) {
        EntityManager em = Persistence.createEntityManagerFactory("my-persistence-unit").createEntityManager();
        Restaurant restaurant = em.find(Restaurant.class, restaurantId);
        if (restaurant == null) {
            throw new NotFoundException();
        }
        int numCompletedOrders = 0;
        int numCanceledOrders = 0;
        double totalEarnings = 0.0;
        List<Order> orders = em.createQuery("SELECT o FROM Order o WHERE o.restaurant.id = :restaurantId", Order.class)
                .setParameter("restaurantId", restaurantId)
                .getResultList();
        for (Order order : orders) {
            if (order.getOrderStatus().equals("completed")) {
                numCompletedOrders++;
                totalEarnings += order.getTotalPrice();
            } else if (order.getOrderStatus().equals("canceled")) {
                numCanceledOrders++;
            }
        }
        em.close();
        return "Total earnings: $" + String.format("%.2f", totalEarnings) +
               "\nNumber of completed orders: " + numCompletedOrders +
               "\nNumber of canceled orders: " + numCanceledOrders;
    }
	public void SignIn (String username, String Password, Role role) {
		User u = new RestaurantOwner();
		u.setUsername(username);
		u.setPassword(Password);
		u.setRole(Role.RESTAURANT_OWNER);
	}

}